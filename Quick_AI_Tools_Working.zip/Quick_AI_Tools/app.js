const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const modal = $('#modalBackdrop'), modalContent = $('#modalContent');
const toast = $('#toast');

function showToast(msg){ toast.textContent=msg; toast.classList.add('show'); clearTimeout(showToast.t); showToast.t=setTimeout(()=>toast.classList.remove('show'),2600); }
function openModal(type){ modalContent.innerHTML = templates[type] || '<p>Tool unavailable.</p>'; modal.classList.add('show'); bindTool(type); }
function closeModal(){modal.classList.remove('show');}
$('#modalClose').onclick=closeModal;
modal.addEventListener('click',e=>{if(e.target===modal)closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
$$('[data-open]').forEach(b=>b.addEventListener('click',()=>openModal(b.dataset.open)));

$('#themeBtn').onclick=()=>{document.body.classList.toggle('dark');localStorage.theme=document.body.classList.contains('dark')?'dark':'light';};
if(localStorage.theme==='dark')document.body.classList.add('dark');
$('#menuBtn').onclick=()=>$('#mobileMenu').classList.toggle('show');
$$('#mobileMenu a').forEach(a=>a.onclick=()=>$('#mobileMenu').classList.remove('show'));

$('#toolSearch').addEventListener('input',e=>{
 const q=e.target.value.toLowerCase().trim(); let count=0;
 $$('#toolsGrid .tool-card').forEach(c=>{const ok=!q||c.dataset.search.includes(q)||c.textContent.toLowerCase().includes(q);c.style.display=ok?'':'none';if(ok)count++;});
 $('#noResults').classList.toggle('hidden',count!==0);
});

const templates={
writer:`<h2>✍️ AI Writer</h2><p>Generate useful copy locally from your topic and style.</p>
<div class="field"><label>Topic</label><input id="wTopic" placeholder="e.g. Instagram caption for a food video"></div>
<div class="field"><label>Style</label><select id="wStyle"><option>Professional</option><option>Friendly</option><option>Short & catchy</option><option>SEO</option></select></div>
<button class="btn primary" id="wGo">Generate</button><div id="wOut" class="output hidden"></div>`,
summarizer:`<h2>📄 PDF Summarizer</h2><p>Choose a PDF. Text extraction happens in your browser using PDF.js.</p>
<div class="upload" id="pdfDrop">📤 Click to select PDF<input id="pdfFile" type="file" accept="application/pdf" hidden></div>
<div id="pdfStatus" class="output hidden"></div><button class="btn primary hidden" id="pdfDownload">Download extracted text</button>`,
rewriter:`<h2>🔄 Text Rewriter</h2><div class="field"><label>Your text</label><textarea id="rText" placeholder="Paste text here..."></textarea></div>
<div class="field"><label>Style</label><select id="rStyle"><option>Simple</option><option>Professional</option><option>Friendly</option></select></div>
<button class="btn primary" id="rGo">Rewrite</button><div id="rOut" class="output hidden"></div>`,
translator:`<h2>🌐 Translator</h2><p>Offline starter translator for common English/Hindi phrases.</p>
<div class="field"><label>Direction</label><select id="trDir"><option value="en-hi">English → Hindi</option><option value="hi-en">Hindi → English</option></select></div>
<div class="field"><textarea id="trText" placeholder="Type a phrase..."></textarea></div><button class="btn primary" id="trGo">Translate</button><div id="trOut" class="output hidden"></div>`,
imagegen:`<h2>🎨 Image Generator</h2><p>Create downloadable SVG artwork from a prompt. This is local and needs no API key.</p>
<div class="field"><input id="iPrompt" placeholder="A neon city at night"></div><button class="btn primary" id="iGo">Generate SVG</button><div id="iOut"></div>`,
bgremove:`<h2>🖼️ Background Remover</h2><p>Works best with photos having a near-uniform corner background. Processing stays on-device.</p>
<div class="upload" id="bgDrop">📤 Select image<input id="bgFile" type="file" accept="image/*" hidden></div><canvas id="bgCanvas" class="preview hidden"></canvas><button class="btn primary hidden" id="bgDownload">Download PNG</button>`,
resume:`<h2>📋 Resume Builder</h2><div class="form-grid">
<div class="field"><label>Name</label><input id="cvName" placeholder="Your name"></div><div class="field"><label>Role</label><input id="cvRole" placeholder="Web Developer"></div>
<div class="field"><label>Email</label><input id="cvEmail" placeholder="you@example.com"></div><div class="field"><label>Phone</label><input id="cvPhone" placeholder="+91..."></div></div>
<div class="field"><label>Summary</label><textarea id="cvSummary" placeholder="Short professional summary"></textarea></div>
<div class="field"><label>Skills</label><input id="cvSkills" placeholder="HTML, CSS, JavaScript, Communication"></div>
<div class="field"><label>Experience / Education</label><textarea id="cvExp" placeholder="Add your experience, education and achievements"></textarea></div>
<button class="btn primary" id="cvGo">Build Resume</button><button class="btn secondary hidden" id="cvPrint">Print / Save PDF</button><div id="cvOut"></div>`,
presentation:`<h2>📽️ Presentation Maker</h2><div class="field"><label>Presentation title</label><input id="pTitle" placeholder="My Presentation"></div>
<div class="field"><label>Slide content (one slide per line)</label><textarea id="pSlides" placeholder="Introduction&#10;Problem&#10;Solution&#10;Conclusion"></textarea></div>
<button class="btn primary" id="pGo">Create Slides</button><div id="pOut" class="slide-output"></div><button class="btn secondary hidden" id="pDownload">Download HTML presentation</button>`,
pdf:`<h2>📄 PDF Tools</h2><p>Use the PDF Summarizer to extract text. You can then save the extracted content as a .txt file.</p><button class="btn primary" data-open="summarizer">Open PDF Summarizer</button>`,
assistant:`<h2>🤖 AI Assistant</h2><p class="assistant-msg">This starter version works without an exposed API key. Type a request and I’ll give a useful local response based on built-in rules.</p>
<div class="field"><textarea id="aText" placeholder="Ask: write a YouTube title, summarize this, give website ideas..."></textarea></div><button class="btn primary" id="aGo">Ask Assistant</button><div id="aOut" class="output hidden"></div>`
};

$('#assistantBtn').onclick=()=>openModal('assistant');

function bindTool(type){
 if(type==='writer') $('#wGo').onclick=()=>{let t=$('#wTopic').value.trim();if(!t)return showToast('Enter a topic');let s=$('#wStyle').value;let out=s==='Short & catchy'?`${t} — simple, useful and worth sharing. 🚀`:s==='SEO'?`Discover ${t}: practical tips, clear ideas and easy steps to get better results. Save this guide and start today.`:s==='Friendly'?`Hey! Let’s talk about ${t}. Here are some simple ideas you can try today — practical, easy and made for you.`:`Here is a polished draft about ${t}:\n\n${t} can be approached with a clear goal, useful information and a simple action plan. Start with the basics, focus on what matters most, and improve step by step.`; $('#wOut').textContent=out;$('#wOut').classList.remove('hidden');};
 if(type==='rewriter') $('#rGo').onclick=()=>{let t=$('#rText').value.trim();if(!t)return showToast('Enter text');let s=$('#rStyle').value;let out=s==='Simple'?t.replace(/\b(utilize|approximately|commence|assistance)\b/gi,m=>({utilize:'use',approximately:'about',commence:'start',assistance:'help'}[m.toLowerCase()]||m)):s==='Friendly'?`Here’s a friendlier version: ${t}`:`Professional version: ${t}`;$('#rOut').textContent=out;$('#rOut').classList.remove('hidden');};
 if(type==='translator') $('#trGo').onclick=()=>{let x=$('#trText').value.trim();let dir=$('#trDir').value;let dict=dir==='en-hi'?enHi:hiEn;let out=x.split(/(\s+|[,.!?])/).map(w=>dict[w.toLowerCase()]||w).join('');$('#trOut').textContent=out;$('#trOut').classList.remove('hidden');};
 if(type==='imagegen') $('#iGo').onclick=generateSVG;
 if(type==='bgremove') setupBg();
 if(type==='resume') setupResume();
 if(type==='presentation') setupPresentation();
 if(type==='summarizer') setupPDF();
 if(type==='assistant') setupAssistant();
 if(type==='pdf') $$('[data-open="summarizer"]').forEach(b=>b.onclick=()=>openModal('summarizer'));
}
const enHi={hello:'नमस्ते',hi:'नमस्ते',thanks:'धन्यवाद',thank:'धन्यवाद',you:'आप',good:'अच्छा',morning:'सुबह',food:'खाना',water:'पानी',please:'कृपया',yes:'हाँ',no:'नहीं',welcome:'स्वागत',friend:'दोस्त',love:'प्यार',india:'भारत',today:'आज',tomorrow:'कल',work:'काम',home:'घर',how:'कैसे',what:'क्या',is:'है',my:'मेरा',name:'नाम'};
const hiEn={'नमस्ते':'hello','धन्यवाद':'thanks','आप':'you','अच्छा':'good','सुबह':'morning','खाना':'food','पानी':'water','कृपया':'please','हाँ':'yes','नहीं':'no','स्वागत':'welcome','दोस्त':'friend','प्यार':'love','भारत':'india','आज':'today','कल':'tomorrow','काम':'work','घर':'home','कैसे':'how','क्या':'what','है':'is','मेरा':'my','नाम':'name'};

function generateSVG(){let p=$('#iPrompt').value.trim()||'Creative abstract art';let esc=p.replace(/[<>&'"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;',"'":'&#39;','"':'&quot;'}[c]));let svg=`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="700"><defs><linearGradient id="g"><stop stop-color="#4f46e5"/><stop offset="1" stop-color="#a855f7"/></linearGradient></defs><rect width="1200" height="700 fill="url(#g)"/><circle cx="250" cy="230" r="150" fill="#ffffff" opacity=".15"/><circle cx="900" cy="480" r="220" fill="#ffffff" opacity=".1"/><text x="600" y="330" text-anchor="middle" fill="white" font-size="48" font-family="Arial" font-weight="700">${esc}</text><text x="600" y="390" text-anchor="middle" fill="white" opacity=".8" font-size="22" font-family="Arial">Created with Quick AI Tools</text></svg>`;let blob=new Blob([svg],{type:'image/svg+xml'});let url=URL.createObjectURL(blob);$('#iOut').innerHTML=`<img class="preview" src="${url}"><a class="btn primary" download="quick-ai-art.svg" href="${url}">Download SVG</a>`;}

function setupBg(){let d=$('#bgDrop'),f=$('#bgFile'),c=$('#bgCanvas');d.onclick=()=>f.click();f.onchange=()=>{let file=f.files[0];if(!file)return;let im=new Image();im.onload=()=>{let max=900,scale=Math.min(1,max/im.width);c.width=im.width*scale;c.height=im.height*scale;let x=c.getContext('2d');x.drawImage(im,0,0,c.width,c.height);let data=x.getImageData(0,0,c.width,c.height), px=data.data;let corner=[];for(let y=0;y<Math.min(15,c.height);y++)for(let z=0;z<Math.min(15,c.width);z++){let i=(y*c.width+z)*4;corner.push([px[i],px[i+1],px[i+2]])}let avg=corner.reduce((a,v)=>a.map((n,i)=>n+v[i]),[0,0,0]).map(n=>n/corner.length);for(let i=0;i<px.length;i+=4){let dist=Math.hypot(px[i]-avg[0],px[i+1]-avg[1],px[i+2]-avg[2]);if(dist<55)px[i+3]=0}x.putImageData(data,0,0);c.classList.remove('hidden');$('#bgDownload').classList.remove('hidden');$('#bgDownload').onclick=()=>c.toBlob(b=>{let u=URL.createObjectURL(b);let a=document.createElement('a');a.href=u;a.download='background-removed.png';a.click();URL.revokeObjectURL(u)},'image/png');};im.src=URL.createObjectURL(file)}}

function setupResume(){$('#cvGo').onclick=()=>{let n=$('#cvName').value||'Your Name',r=$('#cvRole').value||'Professional',e=$('#cvEmail').value,p=$('#cvPhone').value,s=$('#cvSummary').value||'Motivated professional with a strong interest in learning and delivering quality work.',sk=$('#cvSkills').value||'Communication, Problem Solving, Teamwork',ex=$('#cvExp').value||'Add your experience and education here.';$('#cvOut').innerHTML=`<div class="resume-preview" id="resumePrintArea"><h1>${safe(n)}</h1><b>${safe(r)}</b><p>${safe(e)} ${e&&p?' • ':''}${safe(p)}</p><hr><h3>PROFILE</h3><p>${safe(s)}</p><h3>SKILLS</h3><p>${safe(sk)}</p><h3>EXPERIENCE & EDUCATION</h3><p>${safe(ex).replace(/\n/g,'<br>')}</p></div>`;$('#cvPrint').classList.remove('hidden');$('#cvPrint').onclick=()=>window.print()};}
function safe(x){return String(x).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}

function setupPresentation(){$('#pGo').onclick=()=>{let title=$('#pTitle').value||'My Presentation',slides=$('#pSlides').value.split('\n').map(x=>x.trim()).filter(Boolean);if(!slides.length)return showToast('Add slide content');$('#pOut').innerHTML=slides.map((s,i)=>`<div class="slide"><small>SLIDE ${i+1}</small><h3>${safe(title)}</h3><p>${safe(s)}</p></div>`).join('');$('#pDownload').classList.remove('hidden');$('#pDownload').onclick=()=>{let html=`<!doctype html><meta charset="utf-8"><title>${safe(title)}</title><style>body{font-family:Arial;margin:0;background:#111;color:#fff}.slide{height:100vh;display:flex;flex-direction:column;justify-content:center;padding:8vw;box-sizing:border-box}.slide:nth-child(even){background:#312e81}.slide h1{font-size:7vw}.slide p{font-size:3vw}</style>${slides.map((s,i)=>`<section class="slide"><h1>${safe(title)}</h1><p>${safe(s)}</p></section>`).join('')}`;let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([html],{type:'text/html'}));a.download='presentation.html';a.click();};}}

async function setupPDF(){let d=$('#pdfDrop'),f=$('#pdfFile'),status=$('#pdfStatus'),download=$('#pdfDownload');d.onclick=()=>f.click();f.onchange=async()=>{let file=f.files[0];if(!file)return;status.classList.remove('hidden');status.textContent='Reading PDF…';try{const pdfjs=await import('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/pdf.min.mjs');const buf=await file.arrayBuffer();const pdf=await pdfjs.getDocument({data:buf}).promise;let all='';for(let i=1;i<=pdf.numPages;i++){let page=await pdf.getPage(i);let c=await page.getTextContent();all+=c.items.map(x=>x.str).join(' ')+'\\n\\n'}let summary=makeSummary(all);status.textContent=`Pages: ${pdf.numPages}\\n\\nSUMMARY\\n${summary}\\n\\nEXTRACTED TEXT\\n${all.slice(0,12000)}`;download.classList.remove('hidden');download.onclick=()=>downloadText(all,'extracted-pdf.txt');}catch(e){status.textContent='Could not read this PDF. Try a text-based PDF or open it in a modern browser.';}}}
function makeSummary(t){let words=t.replace(/\s+/g,' ').trim().split(' ').filter(Boolean);if(!words.length)return'No text found.';if(words.length<80)return t.trim();let sentences=t.match(/[^.!?]+[.!?]+/g)||[];let score=sentences.map(s=>({s,score:s.split(/\s+/).length})).sort((a,b)=>b.score-a.score).slice(0,5).map(x=>x.s.trim());return score.join(' ')||words.slice(0,80).join(' ')+'…';}
function downloadText(text,name){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:'text/plain'}));a.download=name;a.click();}

function setupAssistant(){$('#aGo').onclick=()=>{let t=$('#aText').value.trim().toLowerCase();if(!t)return showToast('Ask something');let out=t.includes('title')?`Here are 5 title ideas:\\n1. The Ultimate Guide\\n2. 5 Simple Tips That Actually Work\\n3. Try This Before You Start\\n4. Everything You Need to Know\\n5. Quick Tips for Better Results`:t.includes('website')?`Website idea: create a fast, mobile-first tools hub with a searchable tool directory, individual tool pages, FAQ, blog, privacy page and clear navigation.`:t.includes('summar')?`Paste the text you want summarized into the Text Rewriter/other text tools, or upload a text-based PDF in PDF Summarizer.`:`I can help you plan content, write copy, create tool ideas and structure your website. Try asking for a title, website idea, caption or summary.`;$('#aOut').textContent=out;$('#aOut').classList.remove('hidden');}}
